Bryan Battershill
300014415
ITI1121B
This is assignment 3 and is a used to solve the instant insanity puzzle.